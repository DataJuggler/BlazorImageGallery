﻿

#region using statements

#endregion

namespace ObjectLibrary.Enumerations
{

    #region enum SampleEnum : int
    /// <summary>
    /// This enum is only here so that the Enumerations reference compiles.
    /// You can remove this but if you do you also need to remove the reference
    /// in DataManager for this object.
    /// </summary>
    public enum SampleEnum : int
    {
        This = 1,
        Is = 2,
        Only = 3,
        Here = 4,
        As = 5,
        An = 6,
        Example = 7
    }
    #endregion

}
