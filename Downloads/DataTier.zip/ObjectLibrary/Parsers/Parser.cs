

#region using statements

using System;
using ObjectLibrary.Enumerations;

#endregion

namespace ObjectLibrary.Parsers
{

    #region class Parser
    /// <summary>
    /// This class parses the enumerations in the 
    /// Enumerations Folder
    /// </summary>
    public class Parser
    {

        #region Static Methods

        // Add Any Custom Parser Methods Here

        #endregion

    }
    #endregion

}
