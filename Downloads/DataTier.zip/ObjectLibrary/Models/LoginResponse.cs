﻿

#region using statements

using ObjectLibrary.BusinessObjects;

#endregion

namespace ObjectLibrary.Models
{

    #region class LoginResponse
    /// <summary>
    /// This class is used to return an Artist if log in is successful, else a message
    /// </summary>
    public class LoginResponse
    {
        
        #region Private Variables
        private Artist artist;
        private bool success;
        private string message;
        #endregion

        #region Properties

            #region Artist
            /// <summary>
            /// This property gets or sets the value for 'Artist'.
            /// </summary>
            public Artist Artist
            {
                get { return artist; }
                set { artist = value; }
            }
            #endregion
            
            #region HasArtist
            /// <summary>
            /// This property returns true if this object has an 'Artist'.
            /// </summary>
            public bool HasArtist
            {
                get
                {
                    // initial value
                    bool hasArtist = (this.Artist != null);
                    
                    // return value
                    return hasArtist;
                }
            }
            #endregion
            
            #region Message
            /// <summary>
            /// This property gets or sets the value for 'Message'.
            /// </summary>
            public string Message
            {
                get { return message; }
                set { message = value; }
            }
            #endregion
            
            #region Success
            /// <summary>
            /// This property gets or sets the value for 'Success'.
            /// </summary>
            public bool Success
            {
                get { return success; }
                set { success = value; }
            }
            #endregion
            
        #endregion

    }
    #endregion

}
