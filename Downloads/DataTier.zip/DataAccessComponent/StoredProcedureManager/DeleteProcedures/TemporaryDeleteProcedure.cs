

#region using statements

using System;

#endregion

namespace DataAccessComponent.StoredProcedureManager.DeleteProcedures
{

    #region class TemporaryDeleteProcedure
    /// <summary>
    /// This is a temporary class that can be removed
    /// after a the project has been built.
    /// Without this class the references do not build on 
    /// creation of a new project.
    /// </summary>
    class TemporaryDeleteProcedure
    {
        /*
         
         **********************************
         **  This class is only here so the 
         **  project compiles with the 
         **  correct using statements.
         ********************************
          
        */

    }
    #endregion

}
