

#region using statements

using System;

#endregion


namespace DataAccessComponent.StoredProcedureManager.FetchProcedures
{

    #region class TemporaryFetchProcedure
    /// <summary>
    /// This is a temporary class that can be removed
    /// after a IntMap project has Fetch Procedures.
    /// </summary>
    class TemporaryFetchProcedure
    {
        /*
         
         **********************************
         **  This class is only here so the 
         **  project compiles with the 
         **  correct using statements.
         ********************************
          
        */

    }
    #endregion

}



