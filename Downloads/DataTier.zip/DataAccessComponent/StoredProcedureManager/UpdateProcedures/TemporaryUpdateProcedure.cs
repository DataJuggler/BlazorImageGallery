

#region using statements

using System;

#endregion


namespace DataAccessComponent.StoredProcedureManager.UpdateProcedures
{

    #region class TemporaryUpdateProcedure
    /// <summary>
    /// This is a temporary class that can be removed
    /// after a IntMap project has Update Procedures.
    /// </summary>
    class TemporaryUpdateProcedure
    {
        /*
         
         **********************************
         **  This class is only here so the 
         **  project compiles with the 
         **  correct using statements.
         ********************************
          
        */

    }
    #endregion

}
