﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DataAccessComponent.DataManager.Readers
{
    public class TemporaryReader
    {
    }
}
